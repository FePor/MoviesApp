CREATE DATABASE IDMB
ON (
  NAME = IDMB_dat,
  FILENAME = 'c:\temp\IDMB.mdf'
)
LOG ON (
  NAME = IDMB_log,
  FILENAME = 'c:\temp\IDMB.ldf'
)