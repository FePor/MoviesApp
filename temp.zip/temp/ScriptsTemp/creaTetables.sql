USE IDMB
GO


/****** Object:  Table [dbo].[titles]    Script Date: 18/01/2021 21:09:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[title](
	[tconst] [nvarchar](50) NOT NULL PRIMARY KEY,
	[titleType] [nvarchar](50) NULL,
	[primaryTitle] [nvarchar](50) NULL,
	[originalTitle] [nvarchar](50) NULL,
	[isAdult] [nvarchar](50) NULL,
	[startYear] [int] NULL,
	[endYear] [nvarchar](50) NULL,
	[runtimeMinutes] [nvarchar](50) NULL,
	[genres] [nvarchar](50) NULL,
) ON [PRIMARY]
GO


/****** Object:  Table [dbo].[rating]    Script Date: 18/01/2021 21:29:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[rating](
	[tconst] [nvarchar](50) NULL FOREIGN KEY (tconst) REFERENCES Title(tconst),
	[averageRating] [float] NULL,
	[numVotes] [int] NULL
) ON [PRIMARY]
GO


GO

/****** Object:  Table [dbo].[aka]    Script Date: 18/01/2021 22:14:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[akas](
	[titleId] [nvarchar](50) NULL FOREIGN KEY (titleId) REFERENCES Title(tconst),
	[ordering] [nvarchar](50) NULL,
	[title] [nvarchar](50) NULL,
	[region] [nvarchar](50) NULL,
	[language] [nvarchar](50) NULL,
	[types] [nvarchar](50) NULL,
	[attributes] [nvarchar](50) NULL,
	[isOriginalTitle] [nvarchar](50) NULL
) ON [PRIMARY]
GO

GO