USE [IDMB]

UPDATE [dbo].[title]
SET [startYear] = (CASE WHEN ISNUMERIC(startYear)=1 THEN CONVERT(int, startYear)END )

ALTER TABLE [dbo].[title]
ALTER COLUMN [startYear] INT


UPDATE [dbo].[title]
SET [endYear] = (CASE WHEN ISNUMERIC(endYear)=1 THEN CONVERT(int, endYear)END )

ALTER TABLE [dbo].[title]
ALTER COLUMN [endYear] INT

UPDATE [dbo].[title]
SET runtimeMinutes = (CASE WHEN ISNUMERIC(runtimeMinutes)=1 THEN CONVERT(int, runtimeMinutes)END )

ALTER TABLE [dbo].[title]
ALTER COLUMN runtimeMinutes INT


UPDATE [dbo].[title]
SET isAdult = (CASE WHEN ISNUMERIC(isAdult)=1 THEN CONVERT(bit, isAdult)END )

ALTER TABLE [dbo].[title]
ALTER COLUMN isAdult BIT


UPDATE [dbo].[title]
SET genres = REPLACE(genres,'\N',  '')


UPDATE [dbo].[title]
SET runtimeMinutes = (CASE WHEN ISNUMERIC(runtimeMinutes)=1 THEN CONVERT(int, runtimeMinutes)END )

ALTER TABLE [dbo].[title]
ALTER COLUMN runtimeMinutes INT


UPDATE [dbo].[akas]
SET region = REPLACE(region,'\N',  '')



UPDATE [dbo].[akas]
SET [language] = REPLACE([language],'\N',  'he')

