BULK INSERT dbo.title
FROM 'C:\temp\data\title.tsv'
WITH
(
FIELDTERMINATOR = '	',
ROWTERMINATOR = '\n',
FIRSTROW = 2,
KEEPNULLS 
)
GO
BULK INSERT dbo.rating
FROM 'C:\temp\data\rating.tsv'
WITH
(
FIELDTERMINATOR = '	',
ROWTERMINATOR = '\n',
KEEPNULLS
)
GO
BULK INSERT dbo.akas
FROM 'C:\temp\data\akas.tsv'
WITH
(
FIELDTERMINATOR = '	',
ROWTERMINATOR = '\n',
FIRSTROW = 2,
KEEPNULLS
)