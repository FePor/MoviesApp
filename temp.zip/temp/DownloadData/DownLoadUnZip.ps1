﻿Import-Module BitsTransfer

Function DeGZip-File{
    Param(
        $infile,
        $outfile = ($infile -replace '\.gz$','')
        )
    $input = New-Object System.IO.FileStream $inFile, ([IO.FileMode]::Open), ([IO.FileAccess]::Read), ([IO.FileShare]::Read)
    $output = New-Object System.IO.FileStream $outFile, ([IO.FileMode]::Create), ([IO.FileAccess]::Write), ([IO.FileShare]::None)
    $gzipStream = New-Object System.IO.Compression.GzipStream $input, ([IO.Compression.CompressionMode]::Decompress)
    $buffer = New-Object byte[](1024)
    while($true){
        $read = $gzipstream.Read($buffer, 0, 1024)
        if ($read -le 0){break}
        $output.Write($buffer, 0, $read)
        }
    $gzipStream.Close()
    $output.Close()
    $input.Close()
}
Function force-DeGZip{
if (-not (Get-Command Expand-7Zip -ErrorAction Ignore)) {
  Install-Package -Scope CurrentUser -Force 7Zip4PowerShell > $null
}
}


Start-BitsTransfer -Source "https://datasets.imdbws.com/title.basics.tsv.gz" -Destination "c:\temp\title.tar.gz"
DeGZip-File "c:\temp\title.tar.gz" "C:\temp\title.tar"
force-DeGZip
Expand-7Zip C:\temp\title.tar.gz c:\temp\data
Rename-Item -Path "c:\temp\data\data.tsv" -NewName "title.tsv"

Start-BitsTransfer -Source "https://datasets.imdbws.com/title.akas.tsv.gz" -Destination "c:\temp\akas.tar.gz"
DeGZip-File "c:\temp\akas.tar.gz" "C:\temp\akas.tar"
force-DeGZip
Expand-7Zip C:\temp\akas.tar.gz c:\temp\data
Rename-Item -Path "c:\temp\data\data.tsv" -NewName "akas.tsv"

Start-BitsTransfer -Source "https://datasets.imdbws.com/title.ratings.tsv.gz" -Destination "c:\temp\rating.tar.gz"
DeGZip-File "c:\temp\rating.tar.gz" "C:\temp\rating.tar"
force-DeGZip
Expand-7Zip C:\temp\rating.tar.gz c:\temp\data
Rename-Item -Path "c:\temp\data\data.tsv" -NewName "rating.tsv"






