﻿sqlcmd -S DESKTOP-58UFOBM -i C:\temp\ScriptsTemp\script.sql
sqlcmd -S DESKTOP-58UFOBM -i C:\temp\ScriptsTemp\creaTetables.sql
sqlcmd -S DESKTOP-58UFOBM -i C:\temp\ScriptsTemp\bulkinsert.sql
sqlcmd -S DESKTOP-58UFOBM -i C:\temp\ScriptsTemp\changeColumn.sql